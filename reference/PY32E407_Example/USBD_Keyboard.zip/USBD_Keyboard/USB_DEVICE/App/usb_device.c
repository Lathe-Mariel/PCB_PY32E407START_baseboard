/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    usb_device.c
  * @brief   This file provides code for the configuration
  *          of all used USB_DEVICE.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2026 Puya Semiconductor Co.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by Puya under BSD 3-Clause license,
  * the License ; You may not use this file except in compliance with the
  * License.You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2016 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "usb_device.h"
#include "usbd_conf.h"
#include "usbd_core.h"
#include "usbd_desc.h"
#include "usbd_customhid.h"
#include "usbd_customhid_if.h"
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN TD */

/* USER CODE END TD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN Define */

/* USER CODE END Define */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN Macro */

/* USER CODE END Macro */

/* Public variables ---------------------------------------------------------*/
USBD_HandleTypeDef husb_device1;
USBDEV_HandleTypeDef husb1_otg_fs;
/* USER CODE BEGIN PV */
/* USER CODE END PV */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN Private */

/* USER CODE END Private */

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* External variables --------------------------------------------------------*/
/* USER CODE BEGIN EV */

/* USER CODE END EV */

/***************************************
 * @brief USB_DEVICE Init
 **************************************/
void Studio_USB_DEVICE_Init(void)
{
  /* USER CODE BEGIN Studio_USB_DEVICE_Init 0 */

  /* USER CODE END Studio_USB_DEVICE_Init 0 */

  if (USBD_Init(&husb_device1, &USBD1_FS_Desc, USB1_DEVICE_FS) != USBD_OK)
  {
    Error_Handler();
  }
  if (USBD_RegisterClass(&husb_device1, USBD_CUSTOM_HID_CLASS) != USBD_OK)
  {
    Error_Handler();
  }
  if (USBD_CUSTOM_HID_RegisterInterface(&husb_device1, &USBD_CustomHID_fops_USB1) != USBD_OK)
  {
    Error_Handler();
  }
  if (USBD_Start(&husb_device1) != USBD_OK)
  {
    Error_Handler();
  }

  /* USER CODE BEGIN Studio_USB_DEVICE_Init 1 */

  /* USER CODE END Studio_USB_DEVICE_Init 1 */
}

/***************************************
 * @brief USB DEV MspInit
 **************************************/
void HAL_USBDEV_MspInit(USBDEV_HandleTypeDef *husbd)
{
  if (husbd->Instance == USB1_OTG_FS)
  {
  /* USER CODE BEGIN USB1_OTG_FS_MspInit 0 */

  /* USER CODE END USB1_OTG_FS_MspInit 0 */
    __HAL_RCC_USB1_CLK_ENABLE();

    HAL_NVIC_SetPriority(OTG1_FS_IRQn, 6, 0);
    HAL_NVIC_EnableIRQ(OTG1_FS_IRQn);
  /* USER CODE BEGIN USB1_OTG_FS_MspInit 1 */

  /* USER CODE END USB1_OTG_FS_MspInit 1 */
  }
}

/***************************************
 * @brief USB DEV MspDeInit
 **************************************/
void HAL_USBDEV_MspDeInit(USBDEV_HandleTypeDef *husbd)
{
  if (husbd->Instance == USB1_OTG_FS)
  {
  /* USER CODE BEGIN USB1_OTG_FS_MspDeInit 0 */

  /* USER CODE END USB1_OTG_FS_MspDeInit 0 */
    __HAL_RCC_USB1_CLK_DISABLE();

    /* USB1_OTG_FS interrupt Deinit */
    HAL_NVIC_DisableIRQ(OTG1_FS_IRQn);
  /* USER CODE BEGIN USB1_OTG_FS_MspDeInit 1 */

  /* USER CODE END USB1_OTG_FS_MspDeInit 1 */
  }
}

/* USER CODE BEGIN ExternalFunctions */

/* USER CODE END ExternalFunctions */

/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/* USER CODE BEGIN 1 */

/* USER CODE END 1 */
