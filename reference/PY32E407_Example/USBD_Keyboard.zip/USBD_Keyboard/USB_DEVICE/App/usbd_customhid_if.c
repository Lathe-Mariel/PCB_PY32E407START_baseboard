/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    usbd_customhid_if.c
  * @brief   USB Device Custom HID interface file.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2026 Puya Semiconductor Co.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by Puya under BSD 3-Clause license,
  * the License ; You may not use this file except in compliance with the
  * License.You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2016 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "usb_device.h"
#include "usbd_conf.h"
#include "usbd_core.h"
#include "usbd_desc.h"
#include "usbd_customhid.h"
#include "usbd_customhid_if.h"
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN TD */

/* USER CODE END TD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN Define */

/* USER CODE END Define */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN Macro */

/* USER CODE END Macro */

/* Public variables ---------------------------------------------------------*/
/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
static int8_t CUSTOM_HID_Init_USB1(void);
static int8_t CUSTOM_HID_DeInit_USB1(void);
static int8_t CUSTOM_HID_OutEvent_USB1(uint8_t event_idx, uint8_t state);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private variables ---------------------------------------------------------*/
__ALIGN_BEGIN static uint8_t CUSTOM_HID_ReportDesc_USB1[64] __ALIGN_END =
{
  0x05, 0x01,   /* Usage Page (0x01) */
  0x09, 0x06,   /* Usage (0x06) */
  0xA1, 0x01,   /* Collection (Application) */
  0x05, 0x07,   /* Usage Page (0x07) */
  0x19, 0xE0,   /* Usage Minimum (0xE0) */
  0x29, 0xE7,   /* Usage Maximum (0xE7) */
  0x15, 0x00,   /* Logical Minimum (0) */
  0x25, 0x01,   /* Logical Maximum (1) */
  0x75, 0x01,   /* Report Size (1) */
  0x95, 0x08,   /* Report Count (8) */
  0x81, 0x02,   /* Input (Data,Var,Abs) */
  0x95, 0x01,   /* Report Count (1) */
  0x75, 0x08,   /* Report Size (8) */
  0x81, 0x03,   /* Input (Const,Var,Abs) */
  0x05, 0x08,   /* Usage Page (0x08) */
  0x19, 0x01,   /* Usage Minimum (0x01) */
  0x29, 0x05,   /* Usage Maximum (0x05) */
  0x95, 0x05,   /* Report Count (5) */
  0x75, 0x01,   /* Report Size (1) */
  0x91, 0x02,   /* Output (Data,Var,Abs) */
  0x95, 0x01,   /* Report Count (1) */
  0x75, 0x03,   /* Report Size (3) */
  0x91, 0x03,   /* Output (Const,Var,Abs) */
  0x95, 0x06,   /* Report Count (6) */
  0x75, 0x08,   /* Report Size (8) */
  0x15, 0x00,   /* Logical Minimum (0) */
  0x26, 0xFF, 0x00,   /* Logical Maximum (255) */
  0x05, 0x07,   /* Usage Page (0x07) */
  0x19, 0x00,   /* Usage Minimum (0x00) */
  0x29, 0x64,   /* Usage Maximum (0x64) */
  0x81, 0x00,   /* Input (Data,Array,Abs) */
  0xC0,   /* End Collection */
};

USBD_CUSTOM_HID_ItfTypeDef USBD_CustomHID_fops_USB1 =
{
  CUSTOM_HID_ReportDesc_USB1,
  64,
  CUSTOM_HID_Init_USB1,
  CUSTOM_HID_DeInit_USB1,
  CUSTOM_HID_OutEvent_USB1,
};
/* USER CODE BEGIN Private */

/* USER CODE END Private */

/* Private functions ---------------------------------------------------------*/

/**
  * @brief  CUSTOM_HID_Init
  *         Initializes the CUSTOM HID media low layer
  * @param  None
  * @retval Result of the operation: USBD_OK if all operations are OK else USBD_FAIL
  */
static int8_t CUSTOM_HID_Init_USB1(void)
{
  /* USER CODE BEGIN CUSTOM_HID_Init_USB1 */

  /* USER CODE END CUSTOM_HID_Init_USB1 */
  return (0);
}

/**
  * @brief  CUSTOM_HID_DeInit
  *         DeInitializes the CUSTOM HID media low layer
  * @param  None
  * @retval Result of the operation: USBD_OK if all operations are OK else USBD_FAIL
  */
static int8_t CUSTOM_HID_DeInit_USB1(void)
{
  /* USER CODE BEGIN CUSTOM_HID_DeInit_USB1 */

  /* USER CODE END CUSTOM_HID_DeInit_USB1 */
  return (0);
}

/**
  * @brief  CUSTOM_HID_OutEvent
  *         Manage the CUSTOM HID class events
  * @param  event_idx: event index
  * @param  state: event state
  * @retval Result of the operation: USBD_OK if all operations are OK else USBD_FAIL
  */
static int8_t CUSTOM_HID_OutEvent_USB1(uint8_t event_idx, uint8_t state)
{
  /* USER CODE BEGIN CUSTOM_HID_OutEvent_USB1 */

  /* USER CODE END CUSTOM_HID_OutEvent_USB1 */
  return (0);
}

/* USER CODE BEGIN ExternalFunctions */

/* USER CODE END ExternalFunctions */

/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/* USER CODE BEGIN 1 */

/* USER CODE END 1 */
