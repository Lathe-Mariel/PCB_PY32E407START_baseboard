/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    usb_device.c
  * @brief   This file provides code for the configuration
  *          of all used USB_DEVICE.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2026 Puya Semiconductor Co.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by Puya under BSD 3-Clause license,
  * the License ; You may not use this file except in compliance with the
  * License.You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2016 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "usbd_audio.h"
#include "usb_device.h"
#include "usbd_conf.h"
#include "usbd_core.h"
#include "usbd_desc.h"
#include "usbd_audio.h"
#include "usbd_audio_if.h"
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN TD */

/* USER CODE END TD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN Define */

/* USER CODE END Define */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN Macro */

/* USER CODE END Macro */

/* Public variables ---------------------------------------------------------*/
/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN Private */

/* USER CODE END Private */

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* External variables --------------------------------------------------------*/
/* USER CODE BEGIN EV */

/* USER CODE END EV */

/* Private function prototypes -----------------------------------------------*/
static int8_t AUDIO_Init_USB1(uint32_t AudioFreq, uint32_t Volume, uint32_t options);
static int8_t AUDIO_DeInit_USB1(uint32_t options);
static int8_t AUDIO_AudioCmd_USB1(uint8_t *pbuf, uint32_t size, uint8_t cmd);
static int8_t AUDIO_VolumeCtl_USB1(uint8_t vol);
static int8_t AUDIO_MuteCtl_USB1(uint8_t cmd);
static int8_t AUDIO_PeriodicTC_USB1(uint8_t cmd);
static int8_t AUDIO_GetState_USB1(void);

USBD_AUDIO_ItfTypeDef USBD_AUDIO_fops_USB1 =
{
  AUDIO_Init_USB1,
  AUDIO_DeInit_USB1,
  AUDIO_AudioCmd_USB1,
  AUDIO_VolumeCtl_USB1,
  AUDIO_MuteCtl_USB1,
  AUDIO_PeriodicTC_USB1,
  AUDIO_GetState_USB1,
};

/* Private functions ---------------------------------------------------------*/

static int8_t AUDIO_Init_USB1(uint32_t AudioFreq, uint32_t Volume, uint32_t options)
{
  /* USER CODE BEGIN AUDIO_Init_USB1 */

  /* USER CODE END AUDIO_Init_USB1 */
  return (0);
}

static int8_t AUDIO_DeInit_USB1(uint32_t options)
{
  /* USER CODE BEGIN AUDIO_DeInit_USB1 */

  /* USER CODE END AUDIO_DeInit_USB1 */
  return (0);
}

static int8_t AUDIO_AudioCmd_USB1(uint8_t *pbuf, uint32_t size, uint8_t cmd)
{
  /* USER CODE BEGIN AUDIO_AudioCmd_USB1 */

  /* USER CODE END AUDIO_AudioCmd_USB1 */
  return (0);
}

static int8_t AUDIO_VolumeCtl_USB1(uint8_t vol)
{
  /* USER CODE BEGIN AUDIO_VolumeCtl_USB1 */

  /* USER CODE END AUDIO_VolumeCtl_USB1 */
  return (0);
}

static int8_t AUDIO_MuteCtl_USB1(uint8_t cmd)
{
  /* USER CODE BEGIN AUDIO_MuteCtl_USB1 */

  /* USER CODE END AUDIO_MuteCtl_USB1 */
  return (0);
}

static int8_t AUDIO_PeriodicTC_USB1(uint8_t cmd)
{
  /* USER CODE BEGIN AUDIO_PeriodicTC_USB1 */

  /* USER CODE END AUDIO_PeriodicTC_USB1 */
  return (0);
}

static int8_t AUDIO_GetState_USB1(void)
{
  /* USER CODE BEGIN AUDIO_GetState_USB1 */

  /* USER CODE END AUDIO_GetState_USB1 */
  return (0);
}

/* USER CODE BEGIN ExternalFunctions */

/* USER CODE END ExternalFunctions */

/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/* USER CODE BEGIN 1 */

/* USER CODE END 1 */
