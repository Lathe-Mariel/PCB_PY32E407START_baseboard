/**
  ******************************************************************************
  * @file    usbh_conf.c
  * @brief   USB host low level driver bridge file.
  ******************************************************************************
  */

#include "py32e4xx_hal.h"
#include "usbh_core.h"
#include "usbh_conf.h"

USBHOST_HandleTypeDef husb1_otg_fs;

void HAL_USBHOST_SOF_Callback(USBHOST_HandleTypeDef *husbh)
{
  USBH_LL_IncTimer(husbh->pData);
}

void HAL_USBHOST_Connect_Callback(USBHOST_HandleTypeDef *husbh)
{
  uint32_t i = 0;

  USBH_LL_Connect(husbh->pData);

  for (i = 0; i < 200000; i++)
  {
    __asm("nop");
  }
}

void HAL_USBHOST_Disconnect_Callback(USBHOST_HandleTypeDef *husbh)
{
  USBH_LL_Disconnect(husbh->pData);
}

void HAL_USBHOST_PortEnabled_Callback(USBHOST_HandleTypeDef *husbh)
{
  USBH_LL_PortEnabled(husbh->pData);
}

void HAL_USBHOST_PortDisabled_Callback(USBHOST_HandleTypeDef *husbh)
{
  USBH_LL_PortDisabled(husbh->pData);
}

void HAL_USBHOST_HC_NotifyURBChange_Callback(
  USBHOST_HandleTypeDef *husbh,
  uint8_t chnum,
  USBHOST_URBStateTypeDef urb_state
)
{
  (void)husbh;
  (void)chnum;
  (void)urb_state;
}

USBH_StatusTypeDef USBH_LL_Init(USBH_HandleTypeDef *phost)
{
  if (phost->id == USB1_HOST_FS)
  {
    husb1_otg_fs.Instance = USB1_OTG_FS;
    husb1_otg_fs.Init.Host_channels = 8;
    husb1_otg_fs.Init.low_power_enable = 0;
    husb1_otg_fs.Init.Sof_enable = 0;
    husb1_otg_fs.Init.speed = USBHOST_SPEED_FULL;
    husb1_otg_fs.Init.vbus_sensing_enable = 0;
    husb1_otg_fs.Init.phy_itface = USB_OTG_EMBEDDED_PHY;
    husb1_otg_fs.pData = phost;
    phost->pData = &husb1_otg_fs;
    HAL_USBHOST_Init(&husb1_otg_fs);
    USBH_LL_SetTimer(phost, HAL_USBHOST_GetCurrentFrame(&husb1_otg_fs));
  }

  return USBH_OK;
}

USBH_StatusTypeDef USBH_LL_DeInit(USBH_HandleTypeDef *phost)
{
  HAL_USBHOST_DeInit(phost->pData);
  return USBH_OK;
}

USBH_StatusTypeDef USBH_LL_Start(USBH_HandleTypeDef *phost)
{
  HAL_USBHOST_Start(phost->pData);
  return USBH_OK;
}

USBH_StatusTypeDef USBH_LL_Stop(USBH_HandleTypeDef *phost)
{
  HAL_USBHOST_Stop(phost->pData);
  return USBH_OK;
}

USBH_SpeedTypeDef USBH_LL_GetSpeed(USBH_HandleTypeDef *phost)
{
  USBH_SpeedTypeDef speed = USBH_SPEED_FULL;

  switch (HAL_USBHOST_GetCurrentSpeed(phost->pData))
  {
  case 0:
    speed = USBH_SPEED_HIGH;
    break;

  case 1:
    speed = USBH_SPEED_FULL;
    break;

  case 2:
    speed = USBH_SPEED_LOW;
    break;

  default:
    speed = USBH_SPEED_FULL;
    break;
  }

  return speed;
}

USBH_StatusTypeDef USBH_LL_ResetPort(USBH_HandleTypeDef *phost)
{
  HAL_USBHOST_ResetPort(phost->pData);
  return USBH_OK;
}

uint32_t USBH_LL_GetLastXferSize(USBH_HandleTypeDef *phost, uint8_t pipe)
{
  return HAL_USBHOST_HC_GetXferCount(phost->pData, pipe);
}

USBH_StatusTypeDef USBH_LL_OpenPipe(
  USBH_HandleTypeDef *phost,
  uint8_t pipe,
  uint8_t epnum,
  uint8_t dev_address,
  uint8_t speed,
  uint8_t ep_type,
  uint16_t mps
)
{
  HAL_USBHOST_HC_Init(phost->pData, pipe, epnum, dev_address, speed, ep_type, mps);
  return USBH_OK;
}

USBH_StatusTypeDef USBH_LL_ClosePipe(USBH_HandleTypeDef *phost, uint8_t pipe)
{
  HAL_USBHOST_HC_Halt(phost->pData, pipe);
  return USBH_OK;
}

USBH_StatusTypeDef USBH_LL_SubmitURB(
  USBH_HandleTypeDef *phost,
  uint8_t pipe,
  uint8_t direction,
  uint8_t ep_type,
  uint8_t token,
  uint8_t *pbuff,
  uint16_t length,
  uint8_t do_ping
)
{
  HAL_USBHOST_HC_SubmitRequest(phost->pData, pipe, direction, ep_type, token, pbuff, length, do_ping);
  return USBH_OK;
}

USBH_URBStateTypeDef USBH_LL_GetURBState(USBH_HandleTypeDef *phost, uint8_t pipe)
{
  return (USBH_URBStateTypeDef)HAL_USBHOST_HC_GetURBState(phost->pData, pipe);
}

USBH_StatusTypeDef USBH_LL_DriverVBUS(USBH_HandleTypeDef *phost, uint8_t state)
{
  (void)phost;
  (void)state;
  HAL_Delay(200);
  return USBH_OK;
}

USBH_StatusTypeDef USBH_LL_SetToggle(USBH_HandleTypeDef *phost, uint8_t pipe, uint8_t toggle)
{
  USBHOST_HandleTypeDef *husbh = phost->pData;

  if (husbh->hc[pipe].ep_is_in)
  {
    husbh->hc[pipe].toggle_in = toggle;
  }
  else
  {
    husbh->hc[pipe].toggle_out = toggle;
  }

  return USBH_OK;
}

uint8_t USBH_LL_GetToggle(USBH_HandleTypeDef *phost, uint8_t pipe)
{
  USBHOST_HandleTypeDef *husbh = phost->pData;

  if (husbh->hc[pipe].ep_is_in)
  {
    return husbh->hc[pipe].toggle_in;
  }

  return husbh->hc[pipe].toggle_out;
}

void USBH_Delay(uint32_t Delay)
{
  HAL_Delay(Delay);
}
