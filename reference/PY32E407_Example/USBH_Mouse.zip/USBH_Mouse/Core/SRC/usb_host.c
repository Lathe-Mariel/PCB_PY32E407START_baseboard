/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    usb_config.c
  * @brief   This file provides code for the configuration
  *          of all used USB_CONFIG.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2025 puya Co.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by Mcu Studio under BSD 3-Clause license,
  * the License ; You may not use this file except in compliance with the
  * License.You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2016 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "usb_host.h"
#include "usbh_def.h"
#include "usbh_conf.h"
#include "usbh_core.h"
#include "usbh_hid.h"
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN TD */

/* USER CODE END TD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN Define */

/* USER CODE END Define */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN Macro */

/* USER CODE END Macro */

/* Public variables ---------------------------------------------------------*/
USBH_HandleTypeDef husb1_host;
ApplicationTypeDef Appli_state = APPLICATION_IDLE;
/* USER CODE BEGIN PV */
/* USER CODE END PV */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN Private */
uint8_t                     g_usb_first_plugin_flag = 0;
HID_MOUSE_Info_TypeDef *    m_pinfo;
/* USER CODE END Private */

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* External variables --------------------------------------------------------*/
/* USER CODE BEGIN EV */

/* USER CODE END EV */

static void USBH1_UserProcess(USBH_HandleTypeDef *phost, uint8_t id);

/***************************************
 * @brief USB_HOST Init
 **************************************/
void Studio_USB_HOST_Init(void)
{
  /* USER CODE BEGIN Studio_USB_HOST_Init 0 */

  /* USER CODE END Studio_USB_HOST_Init 0 */

  if (USBH_Init(&husb1_host, USBH1_UserProcess, USB1_HOST_FS) != USBH_OK)
  {
    Error_Handler();
  }
  if (USBH_RegisterClass(&husb1_host, USBH_HID_CLASS) != USBH_OK)
  {
    Error_Handler();
  }
  if (USBH_Start(&husb1_host) != USBH_OK)
  {
    Error_Handler();
  }

  /* USER CODE BEGIN Studio_USB_HOST_Init 1 */

  /* USER CODE END Studio_USB_HOST_Init 1 */
}

void HAL_USBHOST_MspInit(USBHOST_HandleTypeDef *husbh)
{
  if (husbh->Instance == USB1_OTG_FS)
  {
    __HAL_RCC_USB1_CLK_ENABLE();
    HAL_NVIC_SetPriority(OTG1_FS_IRQn, 6, 0);
    HAL_NVIC_EnableIRQ(OTG1_FS_IRQn);
  }
}

static void USBH1_UserProcess(USBH_HandleTypeDef *phost, uint8_t id)
{
  /* USER CODE BEGIN USBH1 CALL BACK_1 */
  uint8_t dev_type = 0XFF;
  switch (id)
  {
  case HOST_USER_SELECT_CONFIGURATION:

    break;

  case HOST_USER_DISCONNECTION:
    Appli_state = APPLICATION_DISCONNECT;
    break;

  case HOST_USER_CLASS_ACTIVE:
    Appli_state = APPLICATION_READY;
  
    dev_type = phost->device.CfgDesc.Itf_Desc[phost->device.current_interface].bInterfaceProtocol;

    if (dev_type == HID_MOUSE_BOOT_CODE)
    {
        g_usb_first_plugin_flag = 1;
        printf("mouse connect\r\n");
    }
    else
    {
        printf("nonsupport device\r\n");  
    }
    break;

  case HOST_USER_CONNECTION:
    Appli_state = APPLICATION_START;
    break;

  default:

    break;
  }
  /* USER CODE END USBH1 CALL BACK_1 */
}

/* USER CODE BEGIN ExternalFunctions */

/* USER CODE END ExternalFunctions */

/* USER CODE BEGIN 0 */
void USB_demo(USBH_HandleTypeDef *phost)
{
  if (Appli_state == APPLICATION_READY)
  {
    /* Get device type */
    if (USBH_HID_GetDeviceType(phost) == HID_MOUSE)
    {
      /* Get mouse infomation */
      m_pinfo = USBH_HID_GetMouseInfo(phost);

      if (m_pinfo != NULL)
      {
        /* Print mouse coordinate information */
        printf("x:%d \r\ny:%d \r\n", m_pinfo->x, m_pinfo->y);
      }
    }
  }
}
/* USER CODE END 0 */

/* USER CODE BEGIN 1 */

/* USER CODE END 1 */
