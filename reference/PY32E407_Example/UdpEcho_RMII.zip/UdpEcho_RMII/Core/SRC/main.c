/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    main.c
  * @brief   This file provides code for the configuration
  *          of all used MAIN.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2026 Puya Semiconductor Co.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by Mcu Studio under BSD 3-Clause license,
  * the License ; You may not use this file except in compliance with the
  * License.You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2016 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "rcc.h"
#include "gpio.h"
#include "eth.h"
#include "lwip.h"
#include "uart.h"
/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <lwip/opt.h>
#include <lwip/arch.h>
#include "lwip/init.h"
#include "lwip/netif.h"
#include "lwip/def.h"
#include "lwip/stats.h"
#include "lwip/etharp.h"
#include "lwip/ip.h"
#include "lwip/snmp.h"
#include "lwip/timeouts.h"
#include "lwip/tcp.h"
#include "lwip/udp.h"
#include "lwip/pbuf.h"
#include "netif/etharp.h"
#include "netif/ethernet.h"
#include "ethernetif.h"
#include <stdio.h>
#include <string.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN PV */
uint8_t flag = 0;
static char * st_buffer = "We get a data\r\n";
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN PFP */
static void UDP_Echo_Init(void);
static void udp_demo_callback(void *arg, struct udp_pcb *upcb, struct pbuf *p, \
                              const ip_addr_t *addr, u16_t port);
/* USER CODE END PFP */

/* External functions --------------------------------------------------------*/
/* USER CODE BEGIN ExternalFunctions */

/* USER CODE END ExternalFunctions */

/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */
  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();
  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  Studio_RCC_Init();
  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  Studio_GPIO_Init();
  Studio_UART1_Init();
  /* USER CODE BEGIN 2 */
  /* Wait for button press */
  while(BSP_PB_GetState() == 0) {}

  printf("The local port number is: %d\r\n", LOCAL_PORT);
  
  Studio_LWIP_Init();

  UDP_Echo_Init();
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while(1)
  {
    if(flag)
    {
      flag = 0;
      /* Call the NIC receive function */
      ethernetif_input(&gnetif);
    }
    
    /* Handling timed events in LwIP */
    sys_check_timeouts();
    /* USER CODE END WHILE */
    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/* USER CODE BEGIN 4 */
static void UDP_Echo_Init(void)
{
  struct udp_pcb *udpecho_pcb;
  /* Create a UDP control block */
  udpecho_pcb = udp_new();

  /* Binding UDP control blocks */
  udp_bind(udpecho_pcb, IP_ADDR_ANY, UDP_ECHO_PORT);

  /* Setting UDP Receive Callbacks */
  udp_recv(udpecho_pcb, udp_demo_callback, (void *)st_buffer);
}


static void udp_demo_callback(void *arg, struct udp_pcb *upcb, struct pbuf *p, const ip_addr_t *addr, u16_t port)
{
  struct pbuf *q = NULL;
  const char* reply = "This is reply!\n";

  if(arg)
  {
    printf("%s", (char *)arg);
  }

  pbuf_free(p);

  q = pbuf_alloc(PBUF_TRANSPORT, strlen(reply) + 1, PBUF_RAM);

  if(!q)
  {
    printf("out of PBUF_RAM\n");
    return;
  }

  memset(q->payload, 0, q->len);
  memcpy(q->payload, reply, strlen(reply));
  udp_sendto(upcb, q, addr, port);
  pbuf_free(q);
}

void HAL_ETH_RxCpltCallback(ETH_HandleTypeDef *heth)
{
  flag = 1;
}

void HAL_ETH_TxCpltCallback(ETH_HandleTypeDef *heth)
{

}

void HAL_ETH_ErrorCallback(ETH_HandleTypeDef *heth)
{
  printf("eth err\n");
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();

  while (1)
  {
  }

  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
