/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    usb_host.h
  * @brief   This file provides code for the configuration
  *          of all used USB_HOST.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2026 Puya Semiconductor Co.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by Puya under BSD 3-Clause license,
  * the License ; You may not use this file except in compliance with the
  * License.You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2016 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __USB_HOST_H__
#define __USB_HOST_H__

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "usbh_def.h"
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* USER CODE BEGIN defines */
/* USER CODE END defines */

typedef enum{
  APPLICATION_IDLE = 0,
  APPLICATION_START,
  APPLICATION_READY,
  APPLICATION_DISCONNECT,
}ApplicationTypeDef;

extern USBH_HandleTypeDef husb1_host;
extern ApplicationTypeDef Appli_state;

void Studio_USB_HOST_Init(void);

/* USER CODE BEGIN Prototypes */
#define APPLICATION_RUNNING (APPLICATION_DISCONNECT + 1)
void USB_demo(USBH_HandleTypeDef *phost);
/* USER CODE END Prototypes */

#ifdef __cplusplus
}
#endif

#endif /* __USB_HOST_H__ */
