/**
  ******************************************************************************
  * @file    usbh_conf.h
  * @brief   USB host low level driver configuration file.
  ******************************************************************************
  */

#ifndef __USBH_CONF_H
#define __USBH_CONF_H

#ifdef __cplusplus
extern "C" {
#endif

#include "py32e4xx.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define USBH_MAX_NUM_ENDPOINTS                2
#define USBH_MAX_NUM_INTERFACES               2
#define USBH_MAX_NUM_CONFIGURATION            2
#define USBH_MAX_NUM_SUPPORTED_CLASS          2
#define USBH_KEEP_CFG_DESCRIPTOR              0
#define USBH_MAX_SIZE_CONFIGURATION           256
#define USBH_MAX_DATA_BUFFER                  512
#define USBH_DEBUG_LEVEL                      2
#define USBH_USE_OS                           0

#define USB1_HOST_FS                          0
#define USB2_HOST_FS                          1

#define HOST_HS                               0
#define HOST_FS                               1

#define USBH_malloc                           malloc
#define USBH_free                             free
#define USBH_memset                           memset
#define USBH_memcpy                           memcpy

#if (USBH_DEBUG_LEVEL > 0U)
#define USBH_UsrLog(...)                      \
  do                                          \
  {                                           \
    printf(__VA_ARGS__);                      \
    printf("\n");                             \
  } while (0)
#else
#define USBH_UsrLog(...)                      do { } while (0)
#endif

#if (USBH_DEBUG_LEVEL > 1U)
#define USBH_ErrLog(...)                      \
  do                                          \
  {                                           \
    printf("ERROR: ");                        \
    printf(__VA_ARGS__);                      \
    printf("\n");                             \
  } while (0)
#else
#define USBH_ErrLog(...)                      do { } while (0)
#endif

#if (USBH_DEBUG_LEVEL > 2U)
#define USBH_DbgLog(...)                      \
  do                                          \
  {                                           \
    printf("DEBUG : ");                       \
    printf(__VA_ARGS__);                      \
    printf("\n");                             \
  } while (0)
#else
#define USBH_DbgLog(...)                      do { } while (0)
#endif

#ifdef __cplusplus
}
#endif

#endif /* __USBH_CONF_H */
