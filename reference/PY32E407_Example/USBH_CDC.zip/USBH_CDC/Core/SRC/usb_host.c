/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    usb_host.c
  * @brief   This file provides code for the configuration
  *          of all used USB_HOST.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2026 Puya Semiconductor Co.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by Puya under BSD 3-Clause license,
  * the License ; You may not use this file except in compliance with the
  * License.You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2016 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "usb_host.h"
#include "usbh_def.h"
#include "usbh_conf.h"
#include "usbh_core.h"
#include "usbh_cdc.h"
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN TD */

/* USER CODE END TD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN Define */
#define RX_BUFF_SIZE   128
#define TX_BUFF_SIZE   96
/* USER CODE END Define */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN Macro */

/* USER CODE END Macro */

/* Public variables ---------------------------------------------------------*/
USBH_HandleTypeDef husb1_host;
ApplicationTypeDef Appli_state = APPLICATION_IDLE;
/* USER CODE BEGIN PV */
/* USER CODE END PV */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN Private */
uint8_t CDC_RX_Buffer[RX_BUFF_SIZE];
uint8_t CDC_RX_Flag = 0;
uint8_t CDC_TX_Buffer[TX_BUFF_SIZE];
/* USER CODE END Private */

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* External variables --------------------------------------------------------*/
/* USER CODE BEGIN EV */
uint8_t CDC_TX_Flag = 0;
/* USER CODE END EV */

static void USBH1_UserProcess(USBH_HandleTypeDef *phost, uint8_t id);

/***************************************
 * @brief USB_HOST Init
 **************************************/
void Studio_USB_HOST_Init(void)
{
  /* USER CODE BEGIN Studio_USB_HOST_Init 0 */

  /* USER CODE END Studio_USB_HOST_Init 0 */

  if (USBH_Init(&husb1_host, USBH1_UserProcess, USB1_HOST_FS) != USBH_OK)
  {
    Error_Handler();
  }
  if (USBH_RegisterClass(&husb1_host, USBH_CDC_CLASS) != USBH_OK)
  {
    Error_Handler();
  }
  if (USBH_Start(&husb1_host) != USBH_OK)
  {
    Error_Handler();
  }

  /* USER CODE BEGIN Studio_USB_HOST_Init 1 */

  /* USER CODE END Studio_USB_HOST_Init 1 */
}

void HAL_USBHOST_MspInit(USBHOST_HandleTypeDef *husbh)
{
  if (husbh->Instance == USB1_OTG_FS)
  {
    __HAL_RCC_USB1_CLK_ENABLE();
    HAL_NVIC_SetPriority(OTG1_FS_IRQn, 6, 0);
    HAL_NVIC_EnableIRQ(OTG1_FS_IRQn);
  }
}

static void USBH1_UserProcess(USBH_HandleTypeDef *phost, uint8_t id)
{
  /* USER CODE BEGIN USBH1 CALL BACK_1 */
  switch (id)
  {
  case HOST_USER_SELECT_CONFIGURATION:
    break;

  case HOST_USER_DISCONNECTION:
    Appli_state = APPLICATION_DISCONNECT;
    break;

  case HOST_USER_CLASS_ACTIVE:
    Appli_state = APPLICATION_READY;
    printf("CDC deceive connect\r\n");
    USB_demo(phost);
    break;

  case HOST_USER_CONNECTION:
    Appli_state = APPLICATION_START;
    break;

  default:

    break;
  }
  /* USER CODE END USBH1 CALL BACK_1 */
}

/* USER CODE BEGIN ExternalFunctions */

/* USER CODE END ExternalFunctions */

/* USER CODE BEGIN 0 */
/**
  * @brief  User USB host demo.
  * @param  phost: USB HOST handle
  * @retval None
  */
void USB_demo(USBH_HandleTypeDef *phost)
{
  if (Appli_state == APPLICATION_READY)
  {
    USBH_CDC_Stop(phost);
    memset(CDC_RX_Buffer, 0, RX_BUFF_SIZE);
    USBH_CDC_Receive(phost, CDC_RX_Buffer, RX_BUFF_SIZE);
    Appli_state = APPLICATION_RUNNING;
  }
  else if (Appli_state == APPLICATION_RUNNING)
  {
    if(CDC_RX_Flag == 1)
    {
      printf("\r\nreceive data :\r\n");
      uint16_t i = 0;
      for(i = 0; i < RX_BUFF_SIZE; i++)
      {
        printf("%c",CDC_RX_Buffer[i]);
      }
      printf("\r\n");
      CDC_RX_Flag = 0;
    }
    if(CDC_TX_Flag == 1)
    {
      memset(CDC_TX_Buffer, 0x5A, TX_BUFF_SIZE);
      printf("Sending data ...\r\n");
      USBH_CDC_Transmit(phost, CDC_TX_Buffer, TX_BUFF_SIZE);
      CDC_TX_Flag = 0;
    }
  }
  else if(Appli_state == APPLICATION_DISCONNECT)
  {
    Appli_state = APPLICATION_IDLE;
  }
  else
  {}
}
/* USER CODE END 0 */

/* USER CODE BEGIN 1 */
/**
  * @brief  CDC Receive callbacks
  * @param  phost: USB HOST handle
  * @retval None
  */
void USBH_CDC_ReceiveCallback(USBH_HandleTypeDef *phost)
{
  CDC_RX_Flag = 1;
  USBH_CDC_Receive(phost, CDC_RX_Buffer, RX_BUFF_SIZE);
}

/**
  * @brief  CDC Transmit callbacks
  * @param  phost: USB HOST handle
  * @retval None
  */
void USBH_CDC_TransmitCallback(USBH_HandleTypeDef *phost)
{
  printf(">> Data sent\r\n" );
}
/* USER CODE END 1 */
