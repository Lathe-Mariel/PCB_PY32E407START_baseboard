/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    usb_device.c
  * @brief   This file provides code for the configuration
  *          of all used USB_DEVICE.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2026 Puya Semiconductor Co.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by Puya under BSD 3-Clause license,
  * the License ; You may not use this file except in compliance with the
  * License.You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2016 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "usbd_cdc_if.h"
#include "usb_device.h"
#include "usbd_conf.h"
#include "usbd_core.h"
#include "usbd_desc.h"
#include "usbd_cdc.h"
#include "usbd_cdc_if.h"
/* USER CODE BEGIN Includes */
#include "uart.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN TD */

/* USER CODE END TD */

/* Private define ------------------------------------------------------------*/
#define APP_RX_DATA_SIZE  1024
#define APP_TX_DATA_SIZE  1024
/* USER CODE BEGIN Define */

/* USER CODE END Define */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN Macro */

/* USER CODE END Macro */

/* Public variables ---------------------------------------------------------*/
/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private variables ---------------------------------------------------------*/
uint8_t UserRxBuffer_USB1[APP_RX_DATA_SIZE];
uint8_t UserTxBuffer_USB1[APP_TX_DATA_SIZE];
uint32_t UserTxBufPtrIn_USB1 = 0;
uint32_t UserTxBufPtrOut_USB1 = 0;

extern USBD_HandleTypeDef husb_device1;
/* USER CODE BEGIN Private */

/* USER CODE END Private */

/* Private function prototypes -----------------------------------------------*/
static int8_t CDC_Itf_Init_USB1(void);
static int8_t CDC_Itf_DeInit_USB1(void);
static int8_t CDC_Itf_Control_USB1(uint8_t cmd, uint8_t *pbuf, uint16_t length);
static int8_t CDC_Itf_Receive_USB1(uint8_t *Buf, uint32_t *Len);

USBD_CDC_ItfTypeDef USBD_CDC_fops_USB1 =
{
  CDC_Itf_Init_USB1,
  CDC_Itf_DeInit_USB1,
  CDC_Itf_Control_USB1,
  CDC_Itf_Receive_USB1
};
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* External variables --------------------------------------------------------*/
/* USER CODE BEGIN EV */

/* USER CODE END EV */

/* Private functions ---------------------------------------------------------*/

static int8_t CDC_Itf_Init_USB1(void)
{
  /* USER CODE BEGIN CDC_Itf_Init_USB1 0 */
  Studio_UART1_Init();
  
  HAL_UART_Receive_IT(&huart1, (uint8_t *)&UserTxBuffer_USB1, 1);
  /* USER CODE END CDC_Itf_Init_USB1 0 */
  USBD_CDC_SetTxBuffer(&husb_device1, UserTxBuffer_USB1, 0);
  USBD_CDC_SetRxBuffer(&husb_device1, UserRxBuffer_USB1);
  /* USER CODE BEGIN CDC_Itf_Init_USB1 1 */
  /* USER CODE END CDC_Itf_Init_USB1 1 */
  return (USBD_OK);
}

static int8_t CDC_Itf_DeInit_USB1(void)
{
  /* USER CODE BEGIN CDC_Itf_DeInit_USB1 */

  /* USER CODE END CDC_Itf_DeInit_USB1 */
  return (0);
}

static int8_t CDC_Itf_Control_USB1(uint8_t cmd, uint8_t *pbuf, uint16_t length)
{
  /* USER CODE BEGIN CDC_Itf_Control_USB1 */
  USBD_CDC_LineCodingTypeDef linecoding_USB1 =
  {
    115200, /* baud rate*/
    0x00,   /* stop bits-1*/
    0x00,   /* parity - none*/
    0x08    /* nb. of bits 8*/
  };

  switch (cmd)
  {
    case CDC_SEND_ENCAPSULATED_COMMAND:
      break;
    case CDC_GET_ENCAPSULATED_RESPONSE:
      break;
    case CDC_SET_COMM_FEATURE:
      break;
    case CDC_GET_COMM_FEATURE:
      break;
    case CDC_CLEAR_COMM_FEATURE:
      break;
    case CDC_SET_LINE_CODING:
      linecoding_USB1.bitrate    = (uint32_t)(pbuf[0] | (pbuf[1] << 8) | (pbuf[2] << 16) | (pbuf[3] << 24));
      linecoding_USB1.format     = pbuf[4];
      linecoding_USB1.paritytype = pbuf[5];
      linecoding_USB1.datatype   = pbuf[6];
      break;
    case CDC_GET_LINE_CODING:
      pbuf[0] = (uint8_t)(linecoding_USB1.bitrate);
      pbuf[1] = (uint8_t)(linecoding_USB1.bitrate >> 8);
      pbuf[2] = (uint8_t)(linecoding_USB1.bitrate >> 16);
      pbuf[3] = (uint8_t)(linecoding_USB1.bitrate >> 24);
      pbuf[4] = linecoding_USB1.format;
      pbuf[5] = linecoding_USB1.paritytype;
      pbuf[6] = linecoding_USB1.datatype;
      break;
    case CDC_SET_CONTROL_LINE_STATE:
      break;
    case CDC_SEND_BREAK:
      break;
    default:
      break;
  }
  /* USER CODE END CDC_Itf_Control_USB1 */
  return (0);
}

static int8_t CDC_Itf_Receive_USB1(uint8_t *Buf, uint32_t *Len)
{
  /* USER CODE BEGIN CDC_Itf_Receive_USB1 0 */
  HAL_UART_Transmit(&huart1, Buf, *Len, 1000);
  /* USER CODE END CDC_Itf_Receive_USB1 0 */
  USBD_CDC_ReceivePacket(&husb_device1);
  /* USER CODE BEGIN CDC_Itf_Receive_USB1 1 */
  /* USER CODE END CDC_Itf_Receive_USB1 1 */
  return (USBD_OK);
}

void CDC_Itf_Transmit_USB1(void)
{
  /* USER CODE BEGIN CDC_Itf_Transmit_USB1 0 */

  /* USER CODE END CDC_Itf_Transmit_USB1 0 */

  uint32_t buffptr;
  uint32_t buffsize;

  if (UserTxBufPtrOut_USB1 != UserTxBufPtrIn_USB1)
  {
    if (UserTxBufPtrOut_USB1 > UserTxBufPtrIn_USB1)
    {
      buffsize = APP_TX_DATA_SIZE - UserTxBufPtrOut_USB1;
    }
    else
    {
      buffsize = UserTxBufPtrIn_USB1 - UserTxBufPtrOut_USB1;
    }

    buffptr = UserTxBufPtrOut_USB1;

    USBD_CDC_SetTxBuffer(&husb_device1, (uint8_t *)&UserTxBuffer_USB1[buffptr], buffsize);

    if (USBD_CDC_TransmitPacket(&husb_device1) == USBD_OK)
    {
      UserTxBufPtrOut_USB1 += buffsize;
      if (UserTxBufPtrOut_USB1 == APP_TX_DATA_SIZE)
      {
        UserTxBufPtrOut_USB1 = 0;
      }
    }
  }
  /* USER CODE BEGIN CDC_Itf_Transmit_USB1 1 */

  /* USER CODE END CDC_Itf_Transmit_USB1 1 */
}

/* USER CODE BEGIN ExternalFunctions */

/* USER CODE END ExternalFunctions */

/* USER CODE BEGIN 0 */
/**
  * @brief  Rx Transfer completed callbacks.
  * @param  huart  Pointer to a UART_HandleTypeDef structure that contains
  *                the configuration information for the specified UART module.
  * @retval None
  */
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
  /* Increment Index for buffer writing */
  UserTxBufPtrIn_USB1++;

  /* To avoid buffer overflow */
  if (UserTxBufPtrIn_USB1 == APP_RX_DATA_SIZE)
  {
    UserTxBufPtrIn_USB1 = 0;
  }

  /* Start another reception: provide the buffer pointer with offset and the
   * buffer size */
  HAL_UART_Receive_IT(huart, (uint8_t *) (UserTxBuffer_USB1 + UserTxBufPtrIn_USB1), 1);
}
/* USER CODE END 0 */

/* USER CODE BEGIN 1 */

/* USER CODE END 1 */
